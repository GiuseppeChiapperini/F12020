plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.chaquo.python")
}
android {
    namespace = "com.f1patcher"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.f1patcher"
        minSdk = 24
        targetSdk = 34
        versionCode = 11
        versionName = "2.10.0"
        ndk { abiFilters += listOf("arm64-v8a") }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
}

chaquopy {
    defaultConfig {
        pip { install("cryptography") }
    }
}
