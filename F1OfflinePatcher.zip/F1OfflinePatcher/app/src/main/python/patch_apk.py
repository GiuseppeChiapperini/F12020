"""
patch_apk.py - crea la versione "offline" di F1 Mobile Racing partendo dall'APK originale.

Cosa fa:
  1. apre l'APK e trova lib/arm64-v8a/libil2cpp.so
  2. applica le patch offline (controllando i byte originali di ogni metodo)
  3. ricostruisce l'APK (libreria non compressa e allineata, come zipalign)
  4. rimuove la vecchia firma e firma con una chiave locale (schema APK v2, Android 7+)

Requisiti: Python 3 + libreria "cryptography"  ->  pip install cryptography

Uso:
    python patch_apk.py F1Mobile.apk                    (DEFAULT: profilo "all", tutte le patch insieme)
    python patch_apk.py F1Mobile.apk --profile=none     (solo ri-firma, per capire se il crash dipende dalle patch)
    python patch_apk.py F1Mobile.apk --profile=bypass   (DEFAULT: salta la verifica server)
    python patch_apk.py F1Mobile.apk --extra            (silenzia anche i popup di errore di rete)
    python patch_apk.py F1Mobile.apk --data-url=http://127.0.0.1:8080/   (DEFAULT: i dati scaricabili si cercano su un server locale)
    python patch_apk.py F1Mobile.apk --no-data-url      (lascia l'indirizzo originale dei server Codemasters)
    python patch_apk.py base.apk config.arm64_v8a.apk split_x.apk   (APK divisi: vanno firmati TUTTI
                                                                    con la stessa chiave, quindi passali insieme)

Output: <nome>_offline.apk accanto all'originale.
La chiave di firma viene creata la prima volta (patcher_key.pem / patcher_cert.pem) e riusata
nelle volte successive, cosi' gli aggiornamenti si installano sopra la versione patchata.
"""
import hashlib
import io
import os
import struct
import sys
import zipfile
import zlib
import datetime

TARGET_LIB = "lib/arm64-v8a/libil2cpp.so"
# SHA-256 della libil2cpp.so per cui sono calcolati gli offset qui sotto: su un'altra build il patcher non tocca nulla.
EXPECTED_SHA256 = "7d07f863da4e29d4cbedf367b8977698f0141ae07ffc27b345a82c1760c9d199"

# global-metadata.dat della stessa build: qui c'e' il letterale con l'URL base dei dati scaricabili (DownloadableData).
META_PATH = "assets/bin/Data/Managed/Metadata/global-metadata.dat"
EXPECTED_META_SHA256 = "427ae10804776b2769ade0a8d556f4e2f68da0777f058f79d0349f06375d86d7"
ORIG_DATA_URL = "http://f1mrs.codemasters.com/"
# Dove il gioco va a cercare .ver e bundle. Deve finire con "/" e non puo' essere piu' lungo dell'originale (29 caratteri).
# 127.0.0.1:8080 = server locale (server_dati.py su Termux, oppure sul PC con "adb reverse tcp:8080 tcp:8080").
DEFAULT_DATA_URL = "http://127.0.0.1:8080/"

# ---------------------------------------------------------------- patch del .so
TRUE = bytes.fromhex("20008052" "c0035fd6")      # mov w0,#1 ; ret
RET2 = bytes.fromhex("c0035fd6" "c0035fd6")      # ret ; ret
FALSE = bytes.fromhex("00008052" "c0035fd6")     # mov w0,#0 ; ret
UPTODATE = bytes.fromhex("40008052" "c0035fd6")  # mov w0,#2 ; ret   (ClientVersionStatus.UpToDate)

P_HTTP   = ("HttpClient.get_AllowOfflineMode",            0x237096c, "00604239c0035fd6", TRUE)
P_GTSNET = ("GTSNetworkManager.get_AllowOfflineMode",     0x32aedbc, "f657bda9f44f01a9", TRUE)
P_DBG_A  = ("GTSpiritDebugSettings.get_AllowOfflineMode", 0x2e49f3c, "00804039c0035fd6", TRUE)
P_DBG_F  = ("GTSpiritDebugSettings.get_ForceOfflineMode", 0x2e43470, "00844039c0035fd6", TRUE)
# Il gestore di rete attivo (F1NetworkManager) NON ridefinisce AllowOfflineMode: usa la versione base di INetworkManager,
# che restituisce sempre false (mov w0,wzr ; ret). Senza questa patch il fallback offline non scatta per le richieste.
P_INET_A = ("INetworkManager.get_AllowOfflineMode",        0x237c59c, "e0031f2ac0035fd6", TRUE)
# F1InitializerGameContext.HandleInitializationFinished: GameManager.StartGame (= entra nel menu) viene chiamato solo se il profilo
# e' "Signed" oppure INetworkManager.AllowOfflineMode (slot virtuale) e' true; altrimenti salta tutto SENZA errori e il gioco resta
# fermo prima del menu. Qui azzeriamo quel salto (tbz w0,#0,+0x98 -> nop): StartGame parte sempre.
P_START  = ("F1InitializerGameContext.HandleInitializationFinished: StartGame sempre", 0x2cd042c, "c0040036e1031faa",
            bytes.fromhex("1f2003d5" "e1031faa"))
# F1ErrorGameContext.LaunchConnection ("riprova connessione"): disconnette GameSparks, cancella i dialoghi, chiama GameManager.RestartGame
# e rifa' tutta l'inizializzazione. E' l'unico percorso (oltre a un pannello di debug) che riporta alla schermata di caricamento:
# se dopo il menu un errore di rete "pesante" scatta, il gioco si riavvia in loop. Con ret il gioco resta dov'e'.
P_NORESTART = ("F1ErrorGameContext.LaunchConnection (niente riavvio)", 0x2e15d20, "f657bda9f44f01a9", RET2)
# TutorialManager.ShouldLaunchOnboardingRace: su un'installazione nuova (nessun PlayerPrefs del tutorial) restituisce true, e
# GameStartContextSelector.EvaluateStartContext sceglie la gara di onboarding invece del menu principale. Quella gara dipende dai
# dati/salvataggi del server e, offline, riporta alla schermata di caricamento. Con FALSE si va dritti al menu.
P_NOONBOARD = ("TutorialManager.ShouldLaunchOnboardingRace (salta onboarding)", 0x2ae7c38, "f44fbea9fd7b01a9", FALSE)
P_GSMAN  = ("GSManager.get_IsInOfflineMode",              0x2ed3f18, "084040b91f0d0071", TRUE)
# --- bypass del controllo server (verificati leggendo il codice di F1InitializerGameContext e F1NetworkManager)
# La sequenza di avvio aspetta ClientVersionStatus: se resta UnChecked aspetta all'infinito, se e' CheckFail/NewVersionOnServer
# abortisce. Qui lo forziamo a UpToDate, cosi' il gioco non dipende da nessuna risposta del server.
P_VER    = ("IServerInfoGameContext.get_ClientVersionStatus", 0x2a15294, "002840b9c0035fd6", UPTODATE)
# IgnoreServerState: IsServerRunning() risponde sempre true e salta CheckRootServerStateAndClientVersionStatus
P_IGN    = ("INetworkManager.get_IgnoreServerState",          0x237c1d8, "00984039c0035fd6", TRUE)
# UseRootServer=false: non scarica il "server root" (usa la lista server gia' presente nel gioco)
P_ROOT   = ("INetworkManager.get_UseRootServer",              0x237c1d0, "00944039c0035fd6", FALSE)
P_NETERR = ("GTSLightErrorHandler.HandleNetworkError (niente popup di errore rete)", 0x2e427c8, "f44fbea9fd7b01a9", RET2)
PATCH_EXTRA = [P_NETERR]

# Profili: dal meno invasivo al piu' invasivo. Se il gioco crasha all'avvio, prova il precedente.
#  none  : NESSUNA patch al codice, solo ri-firmato (diagnostica: se anche questo si chiude, il problema non e' la logica offline)
#  bypass: force + ClientVersionStatus=UpToDate + IgnoreServerState + UseRootServer=false + StartGame sempre (entra nel menu senza risposte dal server)
#  min   : abilita solo il fallback offline previsto dal gioco (ogni richiesta GameSparks ha PerformOffline)
#  std   : min + flag di debug AllowOfflineMode            (DEFAULT)
#  force : std + ForceOfflineMode (salta del tutto la connessione)
#  full  : force + GSManager.IsInOfflineMode sempre true   (la patch originale: la piu' rischiosa)
PROFILES = {
    "none":   [],
    "min":   [P_HTTP, P_GTSNET, P_INET_A],
    "std":   [P_HTTP, P_GTSNET, P_INET_A, P_DBG_A],
    "force": [P_HTTP, P_GTSNET, P_INET_A, P_DBG_A, P_DBG_F],
    "full":  [P_HTTP, P_GTSNET, P_INET_A, P_DBG_A, P_DBG_F, P_GSMAN],
    "bypass": [P_HTTP, P_GTSNET, P_INET_A, P_DBG_A, P_DBG_F, P_VER, P_IGN, P_ROOT, P_START, P_NORESTART, P_NOONBOARD],
    # all: TUTTE le patch insieme (bypass + GSManager.IsInOfflineMode + niente popup errori rete). E' l'unica opzione dell'app.
    "all":   [P_HTTP, P_GTSNET, P_INET_A, P_DBG_A, P_DBG_F, P_GSMAN, P_VER, P_IGN, P_ROOT, P_START, P_NORESTART, P_NOONBOARD, P_NETERR],
}
DEFAULT_PROFILE = "all"


def patch_so(data, extra, profile=DEFAULT_PROFILE):
    """Ritorna (nuovi_byte, numero_patch_applicate)."""
    if hashlib.sha256(data).hexdigest() != EXPECTED_SHA256:
        print("   [!] SHA-256 della libreria diverso dalla build attesa: non la tocco")
        return bytes(data), 0
    d = bytearray(data)
    if d[:4] != b"\x7fELF" or d[4] != 2 or struct.unpack_from("<H", d, 18)[0] != 183:
        print("   [!] la libreria non e' un ELF arm64")
        return bytes(d), 0
    phoff = struct.unpack_from("<Q", d, 0x20)[0]
    phsz, phnum = struct.unpack_from("<HH", d, 0x36)
    loads = []
    for i in range(phnum):
        t, fl, off, va, pa, fsz, msz, al = struct.unpack_from("<IIQQQQQQ", d, phoff + i * phsz)
        if t == 1:
            loads.append((va, off, fsz))

    def file_off(va):
        for v, o, s in loads:
            if v <= va < v + s:
                return o + (va - v)
        return None

    applied = 0
    skipped = []
    todo = list(PROFILES[profile])
    if extra:
        todo += [x for x in PATCH_EXTRA if x not in todo]
    for nome, va, atteso, nuovo in todo:
        fo = file_off(va)
        if fo is None:
            print(f"   [SKIP] {nome}: indirizzo 0x{va:x} non trovato")
            skipped.append(nome)
            continue
        attuale = bytes(d[fo:fo + 8])
        if attuale == nuovo:
            print(f"   [GIA'] {nome}")
            continue
        if attuale.hex() != atteso:
            print(f"   [SKIP] {nome}: a 0x{va:x} trovo {attuale.hex()} invece di {atteso}")
            skipped.append(nome)
            continue
        d[fo:fo + 8] = nuovo
        print(f"   [OK]   {nome}")
        applied += 1
    print(f"   --> patch applicate: {applied}/{len(todo)}" + (f" (saltate: {len(skipped)})" if skipped else ""))
    return bytes(d), applied


# ---------------------------------------------------------------- patch dei metadati (URL dati scaricabili)
def patch_metadata(data, new_url):
    """Cambia il letterale 'http://f1mrs.codemasters.com/' in new_url. Ritorna (nuovi_byte, 0 o 1)."""
    if hashlib.sha256(data).hexdigest() != EXPECTED_META_SHA256:
        print("   [!] global-metadata.dat diverso dalla build attesa: non lo tocco")
        return bytes(data), 0
    old, new = ORIG_DATA_URL.encode(), new_url.encode()
    if not new_url.startswith("http") or not new_url.endswith("/"):
        print("   [!] l'URL deve iniziare con http e finire con '/': non lo tocco")
        return bytes(data), 0
    if len(new) > len(old):
        print(f"   [!] URL troppo lungo ({len(new)} > {len(old)} caratteri): non lo tocco")
        return bytes(data), 0
    d = bytearray(data)
    if struct.unpack_from("<II", d, 0) != (0xFAB11BAF, 24):
        print("   [!] metadati non in versione 24: non li tocco")
        return bytes(data), 0
    slo, sls, sld = struct.unpack_from("<III", d, 8)
    hits = []
    for i in range(sls // 8):
        ln, off = struct.unpack_from("<II", d, slo + i * 8)
        if ln == len(old) and bytes(d[sld + off:sld + off + ln]) == old:
            hits.append((i, off))
    if len(hits) != 1:
        print(f"   [SKIP] letterale dell'URL trovato {len(hits)} volte (atteso: 1)")
        return bytes(data), 0
    i, off = hits[0]
    d[sld + off:sld + off + len(old)] = new + b"\0" * (len(old) - len(new))
    struct.pack_into("<I", d, slo + i * 8, len(new))
    print(f"   [OK]   URL dati scaricabili: {ORIG_DATA_URL} -> {new_url}")
    return bytes(d), 1


# ---------------------------------------------------------------- chiave di firma
def load_or_create_key(folder):
    try:
        from cryptography import x509
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import rsa
        from cryptography.x509.oid import NameOID
    except ImportError:
        sys.exit("Manca la libreria 'cryptography'. Installala con:  pip install cryptography")

    kp = os.path.join(folder, "patcher_key.pem")
    cp = os.path.join(folder, "patcher_cert.pem")
    if os.path.exists(kp) and os.path.exists(cp):
        key = serialization.load_pem_private_key(open(kp, "rb").read(), None)
        cert = x509.load_pem_x509_certificate(open(cp, "rb").read())
    else:
        print("Creo la chiave di firma (una volta sola)...")
        key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "F1 Offline Patch")])
        cert = (x509.CertificateBuilder().subject_name(name).issuer_name(name)
                .public_key(key.public_key()).serial_number(x509.random_serial_number())
                .not_valid_before(datetime.datetime(2020, 1, 1))
                .not_valid_after(datetime.datetime(2060, 1, 1))
                .sign(key, hashes.SHA256()))
        open(kp, "wb").write(key.private_bytes(
            serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
            serialization.NoEncryption()))
        open(cp, "wb").write(cert.public_bytes(serialization.Encoding.PEM))
    cert_der = cert.public_bytes(serialization.Encoding.DER)
    pub_der = key.public_key().public_bytes(
        serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)
    return key, cert_der, pub_der


# ---------------------------------------------------------------- firma APK v2
def lp(b):
    return struct.pack("<I", len(b)) + b


def make_v2_block(sec1, cd, count, key, cert_der, pub_der):
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.asymmetric import padding

    eocd_for_digest = struct.pack("<4sHHHHIIH", b"PK\x05\x06", 0, 0, count, count,
                                  len(cd), len(sec1), 0)
    chunk = 1 << 20
    digests, n = [], 0
    for sec in (sec1, cd, eocd_for_digest):
        mv = memoryview(sec)
        for i in range(0, len(sec), chunk):
            c = mv[i:i + chunk]
            h = hashlib.sha256()
            h.update(b"\xa5" + struct.pack("<I", len(c)))
            h.update(c)
            digests.append(h.digest())
            n += 1
    top = hashlib.sha256(b"\x5a" + struct.pack("<I", n) + b"".join(digests)).digest()

    ALGO = 0x0103  # RSASSA-PKCS1-v1_5 + SHA-256
    signed_data = (lp(lp(struct.pack("<I", ALGO) + lp(top)))   # digests
                   + lp(lp(cert_der))                          # certificati
                   + lp(b""))                                  # attributi aggiuntivi
    sig = key.sign(signed_data, padding.PKCS1v15(), hashes.SHA256())
    signer = lp(signed_data) + lp(lp(struct.pack("<I", ALGO) + lp(sig))) + lp(pub_der)
    signers = lp(lp(signer))
    pair = struct.pack("<QI", 4 + len(signers), 0x7109871A) + signers
    size = len(pair) + 8 + 16
    return struct.pack("<Q", size) + pair + struct.pack("<Q", size) + b"APK Sig Block 42"


# ---------------------------------------------------------------- ricostruzione APK
def is_old_signature(name):
    up = name.upper()
    if not up.startswith("META-INF/") or up.count("/") != 1:
        return False
    return up.endswith((".SF", ".RSA", ".DSA", ".EC")) or up == "META-INF/MANIFEST.MF"


def rebuild(src, dst, key, cert_der, pub_der, extra, profile=DEFAULT_PROFILE, data_url=DEFAULT_DATA_URL):
    raw = open(src, "rb").read()
    zf = zipfile.ZipFile(io.BytesIO(raw))
    out = bytearray()
    cd = bytearray()
    count = 0
    n_patched = 0
    found_lib = False
    found_meta = False

    for zi in zf.infolist():
        name = zi.filename
        if is_old_signature(name):
            continue
        nb = name.encode("utf-8" if zi.flag_bits & 0x800 else "cp437")

        off = zi.header_offset
        (_s, _v, _f, _m, ltime, ldate, _c, _cs, _us, nl, el) = struct.unpack_from("<4s5H3I2H", raw, off)
        start = off + 30 + nl + el
        payload = raw[start:start + zi.compress_size]
        method, crc, csize, usize = zi.compress_type, zi.CRC, zi.compress_size, zi.file_size

        if name == TARGET_LIB:
            found_lib = True
            print(f" - {name}")
            new, n = patch_so(zf.read(zi), extra, profile)
            if n:
                payload, method = new, 0
                crc, csize, usize = zlib.crc32(new) & 0xFFFFFFFF, len(new), len(new)
                n_patched += n

        elif name == META_PATH and data_url and profile != "none":
            found_meta = True
            print(f" - {name}")
            new, n = patch_metadata(zf.read(zi), data_url)
            if n:
                payload, method = new, 0
                crc, csize, usize = zlib.crc32(new) & 0xFFFFFFFF, len(new), len(new)
                n_patched += n

        align = 0
        if method == 0 and not name.endswith("/"):
            align = 16384 if name.endswith(".so") else 4
        ext = b""
        if align:
            pad = (-(len(out) + 30 + len(nb))) % align
            if 0 < pad < 4:
                pad += align
            if pad:
                ext = struct.pack("<HH", 0xD935, pad - 4) + b"\0" * (pad - 4)

        flag = zi.flag_bits & ~0x08          # niente data descriptor: scriviamo crc/size veri
        need = 20 if method else 10
        local_off = len(out)
        out += struct.pack("<4sHHHHHIIIHH", b"PK\x03\x04", need, flag, method, ltime, ldate,
                           crc, csize, usize, len(nb), len(ext))
        out += nb + ext + payload
        cd += struct.pack("<4s6H3I5H2I", b"PK\x01\x02",
                          (zi.create_system << 8) | zi.create_version, need, flag, method,
                          ltime, ldate, crc, csize, usize, len(nb), 0, 0, 0,
                          zi.internal_attr, zi.external_attr, local_off)
        cd += nb
        count += 1

    sec1, cdb = bytes(out), bytes(cd)
    del out, cd
    block = make_v2_block(sec1, cdb, count, key, cert_der, pub_der)
    eocd = struct.pack("<4sHHHHIIH", b"PK\x05\x06", 0, 0, count, count,
                       len(cdb), len(sec1) + len(block), 0)
    with open(dst, "wb") as f:
        f.write(sec1)
        f.write(block)
        f.write(cdb)
        f.write(eocd)
    return n_patched if found_lib else "nolib"   # "nolib" = questo APK non ha la libreria (i metadati vengono patchati comunque)


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    extra = "--extra" in sys.argv
    profile = DEFAULT_PROFILE
    data_url = DEFAULT_DATA_URL
    for a in sys.argv[1:]:
        if a.startswith("--profile="):
            profile = a.split("=", 1)[1]
        elif a.startswith("--data-url="):
            data_url = a.split("=", 1)[1]
        elif a == "--no-data-url":
            data_url = None
    if profile not in PROFILES:
        sys.exit("Profilo sconosciuto. Scegli tra: " + ", ".join(PROFILES))
    if not args:
        print(__doc__)
        sys.exit(1)

    folder = os.path.dirname(os.path.abspath(__file__))
    key, cert_der, pub_der = load_or_create_key(folder)
    multi = len(args) > 1
    patched_total = 0

    for src in args:
        if not os.path.exists(src):
            sys.exit(f"File non trovato: {src}")
        base, ext = os.path.splitext(src)
        dst = base + "_offline" + (ext or ".apk")
        print(f"\n== {src}")
        res = rebuild(src, dst, key, cert_der, pub_der, extra, profile, data_url)
        if res == "nolib":
            if not multi:
                sys.exit("Questo APK non contiene lib/arm64-v8a/libil2cpp.so.\n"
                         "Se il gioco e' diviso in piu' APK, passali tutti insieme "
                         "(quello con la libreria e' di solito config.arm64_v8a.apk).")
            print("   (nessuna libreria da patchare, solo ri-firmato)")
        else:
            patched_total += res
        bad = zipfile.ZipFile(dst).testzip()
        if bad:
            sys.exit(f"Errore: file corrotto nell'APK generato ({bad})")
        print(f"   -> {dst}  ({os.path.getsize(dst) / 1e6:.1f} MB)")

    if profile == "none":
        print("\nFatto: APK ri-firmato senza modifiche al codice (profilo none). Disinstalla l'originale e installa.")
    elif patched_total == 0:
        print("\nATTENZIONE: nessuna patch applicata (build diversa da quella attesa?).")
    else:
        print(f"\nFatto: {patched_total} patch applicate.")
        print("Disinstalla l'app originale e installa il nuovo APK (la firma e' cambiata).")


if __name__ == "__main__":
    main()
