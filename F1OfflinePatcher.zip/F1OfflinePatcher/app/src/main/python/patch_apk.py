"""
patch_apk.py - crea la versione "offline" di F1 Mobile Racing partendo dall'APK originale.

Cosa fa:
  1. apre l'APK e trova lib/arm64-v8a/libil2cpp.so
  2. applica le patch offline (controllando i byte originali di ogni metodo)
  3. ricostruisce l'APK (libreria non compressa e allineata, come zipalign)
  4. rimuove la vecchia firma e firma con una chiave locale (schema APK v2, Android 7+)

Build supportate (riconosciute dallo SHA-256 di libil2cpp.so):
  - 90ae142f... = 5.4.11 (versionCode 24001341): tabella di 904 patch identica a f1mobile_patcher_23(1).py
  - 7d07f863... = patch a livello di metodo (profili none/min/std/force/full/bypass/all)

Requisiti: Python 3 + libreria "cryptography"  ->  pip install cryptography

Uso:
    python patch_apk.py F1Mobile.apk                    (DEFAULT: profilo "all", tutte le patch insieme)
    python patch_apk.py F1Mobile.apk --profile=none     (solo ri-firma, per capire se il crash dipende dalle patch)
    python patch_apk.py F1Mobile.apk --profile=bypass   (DEFAULT: salta la verifica server)
    python patch_apk.py F1Mobile.apk --extra            (silenzia anche i popup di errore di rete)
    python patch_apk.py base.apk config.arm64_v8a.apk split_x.apk   (APK divisi: vanno firmati TUTTI
                                                                    con la stessa chiave, quindi passali insieme)

Output: <nome>_offline.apk accanto all'originale.
La chiave di firma viene creata la prima volta (patcher_key.pem / patcher_cert.pem) e riusata
nelle volte successive, cosi' gli aggiornamenti si installano sopra la versione patchata.
"""
import hashlib
import io
import os
import struct
import sys
import zipfile
import zlib
import datetime

TARGET_LIB = "lib/arm64-v8a/libil2cpp.so"
# SHA-256 della libil2cpp.so per cui sono calcolati gli offset qui sotto: su un'altra build il patcher non tocca nulla.
EXPECTED_SHA256 = "7d07f863da4e29d4cbedf367b8977698f0141ae07ffc27b345a82c1760c9d199"

# ---------------------------------------------------------------- patch del .so
TRUE = bytes.fromhex("20008052" "c0035fd6")      # mov w0,#1 ; ret
RET2 = bytes.fromhex("c0035fd6" "c0035fd6")      # ret ; ret
FALSE = bytes.fromhex("00008052" "c0035fd6")     # mov w0,#0 ; ret
UPTODATE = bytes.fromhex("40008052" "c0035fd6")  # mov w0,#2 ; ret   (ClientVersionStatus.UpToDate)

P_HTTP   = ("HttpClient.get_AllowOfflineMode",            0x237096c, "00604239c0035fd6", TRUE)
P_GTSNET = ("GTSNetworkManager.get_AllowOfflineMode",     0x32aedbc, "f657bda9f44f01a9", TRUE)
P_DBG_A  = ("GTSpiritDebugSettings.get_AllowOfflineMode", 0x2e49f3c, "00804039c0035fd6", TRUE)
P_DBG_F  = ("GTSpiritDebugSettings.get_ForceOfflineMode", 0x2e43470, "00844039c0035fd6", TRUE)
# Il gestore di rete attivo (F1NetworkManager) NON ridefinisce AllowOfflineMode: usa la versione base di INetworkManager,
# che restituisce sempre false (mov w0,wzr ; ret). Senza questa patch il fallback offline non scatta per le richieste.
P_INET_A = ("INetworkManager.get_AllowOfflineMode",        0x237c59c, "e0031f2ac0035fd6", TRUE)
# F1InitializerGameContext.HandleInitializationFinished: GameManager.StartGame (= entra nel menu) viene chiamato solo se il profilo
# e' "Signed" oppure INetworkManager.AllowOfflineMode (slot virtuale) e' true; altrimenti salta tutto SENZA errori e il gioco resta
# fermo prima del menu. Qui azzeriamo quel salto (tbz w0,#0,+0x98 -> nop): StartGame parte sempre.
P_START  = ("F1InitializerGameContext.HandleInitializationFinished: StartGame sempre", 0x2cd042c, "c0040036e1031faa",
            bytes.fromhex("1f2003d5" "e1031faa"))
# F1ErrorGameContext.LaunchConnection ("riprova connessione"): disconnette GameSparks, cancella i dialoghi, chiama GameManager.RestartGame
# e rifa' tutta l'inizializzazione. E' l'unico percorso (oltre a un pannello di debug) che riporta alla schermata di caricamento:
# se dopo il menu un errore di rete "pesante" scatta, il gioco si riavvia in loop. Con ret il gioco resta dov'e'.
P_NORESTART = ("F1ErrorGameContext.LaunchConnection (niente riavvio)", 0x2e15d20, "f657bda9f44f01a9", RET2)
# TutorialManager.ShouldLaunchOnboardingRace: su un'installazione nuova (nessun PlayerPrefs del tutorial) restituisce true, e
# GameStartContextSelector.EvaluateStartContext sceglie la gara di onboarding invece del menu principale. Quella gara dipende dai
# dati/salvataggi del server e, offline, riporta alla schermata di caricamento. Con FALSE si va dritti al menu.
P_NOONBOARD = ("TutorialManager.ShouldLaunchOnboardingRace (salta onboarding)", 0x2ae7c38, "f44fbea9fd7b01a9", FALSE)
P_GSMAN  = ("GSManager.get_IsInOfflineMode",              0x2ed3f18, "084040b91f0d0071", TRUE)
# --- bypass del controllo server (verificati leggendo il codice di F1InitializerGameContext e F1NetworkManager)
# La sequenza di avvio aspetta ClientVersionStatus: se resta UnChecked aspetta all'infinito, se e' CheckFail/NewVersionOnServer
# abortisce. Qui lo forziamo a UpToDate, cosi' il gioco non dipende da nessuna risposta del server.
P_VER    = ("IServerInfoGameContext.get_ClientVersionStatus", 0x2a15294, "002840b9c0035fd6", UPTODATE)
# IgnoreServerState: IsServerRunning() risponde sempre true e salta CheckRootServerStateAndClientVersionStatus
P_IGN    = ("INetworkManager.get_IgnoreServerState",          0x237c1d8, "00984039c0035fd6", TRUE)
# UseRootServer=false: non scarica il "server root" (usa la lista server gia' presente nel gioco)
P_ROOT   = ("INetworkManager.get_UseRootServer",              0x237c1d0, "00944039c0035fd6", FALSE)
# --- Patch ricavate dal logcat reale (stack trace = verita'): il gioco parte offline con profilo/database vuoti e il menu lancia eccezioni.
# [retarget di un branch] F1InventoryProfile.GetOwnedItemUids(PurchaseType): il dizionario statico degli oggetti posseduti e' null,
# il codice fa "cbnz x21 / bl throw_NRE". Dove dovrebbe restituire la lista vuota gia' creata (x19) lancia l'eccezione.
# cbnz x21,+8 ; bl throw   ->   cbz x21,<epilogo che ritorna x19> ; nop      (stack: HelmetSelectorPanel.UpdateOfficialHelmetList <- PlayerProfilePanel.Awake)
P_OWNED = ("F1InventoryProfile.GetOwnedItemUids: dizionario null -> lista vuota", 0x2959698, "550000b5a2b2f797",
           bytes.fromhex("350a00b4" "1f2003d5"))
# [stub con ret] MainMenuHeader.SetPlayerFlag(string): GetFlagByCountryCode torna null (nessun paese nel profilo offline) e ResourceFlag.get_Path va in NRE.
# L'effetto e' solo grafico (bandierina). Il resto di UpdateHeader continua.
P_FLAG  = ("MainMenuHeader.SetPlayerFlag (niente bandierina)", 0x2d43cb4, "f657bda9f44f01a9", RET2)
# [stub con valore] RnDHelpers.ComputeNewPartsCount(IRnDProfile) -> int: indicizza liste vuote (ArgumentOutOfRange). Serve solo al badge "nuovi pezzi": 0.
P_PARTS = ("RnDHelpers.ComputeNewPartsCount (badge nuovi pezzi = 0)", 0x2e7d568, "fa67bba9f85f01a9", FALSE)
# [stub con ret] PromoTimerButton.InitPromos: NRE in ShopHelpers.GetCurrentLeaguePromoDescription (catalogo promo del server assente), lanciata da
# MainMenuMainPanel.Show: l'eccezione interrompeva l'inizializzazione del pannello principale. Le promo dello shop non servono offline.
P_PROMO = ("PromoTimerButton.InitPromos (niente promo shop)", 0x2cf2728, "fc6fbaa9fa6701a9", RET2)
P_NETERR = ("GTSLightErrorHandler.HandleNetworkError (niente popup di errore rete)", 0x2e427c8, "f44fbea9fd7b01a9", RET2)
# [chiamata a una risposta che non arriva] FileManager.PerformFileManagerNetworkInitialization(version, serverCheck): mette lo stato a NotReady e
# avvia una richiesta al server per sapere la versione dei file/database. Solo la risposta (OnFilesVersionReceived) porta lo stato a
# ReadyAndUpToDate; DatabaseManager.NetworkUpdateOperation resta in attesa finche' lo stato e' NotReady, quindi senza server il gioco
# resta fermo sulla schermata di caricamento (richiesta in sospeso, database mai caricato). Qui, dopo aver caricato la mappa dei file locale,
# chiamiamo direttamente OnFilesVersionReceived(this, isSuccess=true, hasUpdate=false, 0, null): il gioco imposta lo stato a
# ReadyAndUpToDate (percorso "nessun aggiornamento") e usa i file/database locali (StandaloneFilesMap). Poi salta al normale epilogo.
#   mov x0,x21 ; mov w1,#1 ; mov w2,wzr ; mov w3,wzr ; mov x4,xzr ; bl OnFilesVersionReceived ; b epilogo
P_FILES = ("FileManager.PerformFileManagerNetworkInitialization (stato file subito ReadyAndUpToDate, niente attesa server)", 0x2cdab58,
           "82020012e00315aae103132ab2000094a8c800d0084542f9f40300aa",
           bytes.fromhex("e00315aa" "21008052" "e2031f2a" "e3031f2a" "e4031faa" "db000094" "1a000014"))
# [gara senza dati] DownloadableDataProgressionManager.DownloadDataTagsFromIRace(iRace, levelName, gameModeData, loadFinished).
# Prima di ogni gara (singola, GP, eventi, sandbox) il gioco costruisce la lista dei dati scaricabili che MANCANO sul telefono
# (AddDownloadableDataTagToList aggiunge una pista solo se IsDownloadableDataTagOnDevice e' falso). Lista vuota = dati presenti: la gara
# parte (comportamento originale). Lista non vuota = pista assente: l'originale avvia un download che senza server non finisce mai
# (dialoghi, tentativi di rete, rischio di restare appesi). Con queste 3 patch, se la lista non e' vuota il gioco chiama subito
# loadFinished(cancelled=true, ...): la gara viene annullata senza download e senza blocchi. Nessun blocco "forzato" come nella 2.5.2.
#   0x1012F50  b.lt 0x1012F8C          ->  cset w25, ge          (w25 = 1 se ci sono dati mancanti)
#   0x1012F54  ldr x8,[x23]            ->  b 0x1012F8C           (in entrambi i casi: invoca loadFinished)
#   0x1012FC0  mov w1, wzr             ->  mov w1, w25           (cancelled = dati mancanti)
P_RACE_A = ("DownloadDataTagsFromIRace: w25 = dati mancanti", 0x1012f50, "eb010054", bytes.fromhex("f9b79f1a"))
P_RACE_B = ("DownloadDataTagsFromIRace: sempre loadFinished, niente download", 0x1012f54, "e80240f9", bytes.fromhex("0e000014"))
P_RACE_C = ("DownloadDataTagsFromIRace: cancelled = dati mancanti", 0x1012fc0, "e1031f2a", bytes.fromhex("e103192a"))
P_RACE = [P_RACE_A, P_RACE_B, P_RACE_C]
# [gara: il profilo non ha nessun mazzo] RnDProfile.GetDeck(int): con la lista _decks vuota (profilo offline, nessun dato del server)
# l'indice 0 non e' valido: il gioco scrive "[RnDProfile] Provided deck index (0) is not valid !", restituisce null e
# RnDProfile.ComputeTotalPerformanceStats va in NullReferenceException -> IF1RaceMode.InitMainRacer abortisce e la gara non parte
# (log reale 2.4.2: SingleRaceMode.OnPreStartOperationsComplete <- IF1RaceMode.SelectMainRacer <- InitMainRacer <- GenerateDynamicSettings).
# Con questa patch, sul ramo "indice non valido" si restituisce _vipPartsChoices (campo 0x30, lista sempre creata dal costruttore e
# vuota offline) invece di null: il codice che scorre il mazzo trova 0 slot (stesse istruzioni di lista, tipo riferimento) e continua.
#   0x2E813CC  mov x1,xzr ; mov x0,x20   ->   ldr x0,[x20,#0x30] ; b 0x2E81494   (epilogo che ritorna x0)
P_DECK = ("RnDProfile.GetDeck: indice non valido -> lista vuota invece di null", 0x2e813cc, "e1031faae00314aa",
          bytes.fromhex("801a40f9" "31000014"))
# [stub con ret] LoadingScreenPlayerPresentation.SetFlagImage(string): GetFlagByCountryCode torna null (nessun paese nel profilo offline)
# e la schermata di caricamento della gara va in NullReferenceException (log reale 2.4.2). Solo grafico (bandierina).
P_FLAG2 = ("LoadingScreenPlayerPresentation.SetFlagImage (niente bandierina nel caricamento)", 0x2aacfec, "f657bda9f44f01a9", RET2)
# [gara: nessun mazzo nel profilo] RnDProfile.ComputeTotalPerformanceStats(int deckIndex): costruisce una copia delle statistiche base
# (x19 = new RuntimePerformanceStats(base)) e poi somma i pezzi del mazzo leggendo _decks[deckIndex] (List.get_Item). Il profilo offline ha
# _decks vuota: ArgumentOutOfRangeException (log reale 2.4.2: ComputeTotalPerformanceStats <- GenerateDynamicSettings <- InitMainRacer) e la
# gara non parte. Con questa patch, subito dopo aver creato la copia delle statistiche base, si salta all'epilogo che restituisce x19:
# la macchina del giocatore usa le statistiche base, senza pezzi del mazzo.
#   0x2E835DC  cmn w20,#1   ->   b 0x2E837A4   (mov x0,x19 ; epilogo ; ret)
P_TOTAL = ("RnDProfile.ComputeTotalPerformanceStats: statistiche base, niente pezzi del mazzo", 0x2e835dc, "9f060031", bytes.fromhex("72000014"))
PATCH_EXTRA = [P_NETERR]

# Profili: dal meno invasivo al piu' invasivo. Se il gioco crasha all'avvio, prova il precedente.
#  none  : NESSUNA patch al codice, solo ri-firmato (diagnostica: se anche questo si chiude, il problema non e' la logica offline)
#  bypass: force + ClientVersionStatus=UpToDate + IgnoreServerState + UseRootServer=false + StartGame sempre (entra nel menu senza risposte dal server)
#  min   : abilita solo il fallback offline previsto dal gioco (ogni richiesta GameSparks ha PerformOffline)
#  std   : min + flag di debug AllowOfflineMode            (DEFAULT)
#  force : std + ForceOfflineMode (salta del tutto la connessione)
#  full  : force + GSManager.IsInOfflineMode sempre true   (la patch originale: la piu' rischiosa)
PROFILES = {
    "none":   [],
    "min":   [P_HTTP, P_GTSNET, P_INET_A],
    "std":   [P_HTTP, P_GTSNET, P_INET_A, P_DBG_A],
    "force": [P_HTTP, P_GTSNET, P_INET_A, P_DBG_A, P_DBG_F],
    "full":  [P_HTTP, P_GTSNET, P_INET_A, P_DBG_A, P_DBG_F, P_GSMAN],
    "bypass": [P_HTTP, P_GTSNET, P_INET_A, P_DBG_A, P_DBG_F, P_VER, P_IGN, P_ROOT, P_START, P_NORESTART, P_NOONBOARD, P_FILES, P_RACE_A, P_RACE_B, P_RACE_C, P_OWNED, P_FLAG, P_PARTS, P_PROMO, P_DECK, P_FLAG2, P_TOTAL],
    # all: TUTTE le patch insieme (bypass + GSManager.IsInOfflineMode + niente popup errori rete). E' l'unica opzione dell'app.
    "all":   [P_HTTP, P_GTSNET, P_INET_A, P_DBG_A, P_DBG_F, P_GSMAN, P_VER, P_IGN, P_ROOT, P_START, P_NORESTART, P_NOONBOARD, P_FILES, P_RACE_A, P_RACE_B, P_RACE_C, P_OWNED, P_FLAG, P_PARTS, P_PROMO, P_DECK, P_FLAG2, P_TOTAL, P_NETERR],
}
DEFAULT_PROFILE = "all"

# SHA-256 attesi della libreria DOPO le patch, per profilo ("nome" oppure "nome+extra" se --extra aggiunge qualcosa).
# Se il risultato non coincide, la libreria NON viene modificata: cosi' ogni build e' riproducibile e verificabile.
PATCHED_SHA256 = {
    "none+extra": "2eacd057849a075d77cacf0af2052bae6ff8bf735f8d0ce646c7a0ecb8e908af",
    "min": "ea1b762e8fe269fff7b0d1c4b759d3e8a2dcede319bd84573ea5e8e962e2b8e7",
    "min+extra": "a699f1d5e52f137b2f1858f43a6d75db43c08da8e473aa846a8149ccd98a1a5f",
    "std": "8ec48e7b1f3d2839444bb681d46c66ef10a75f198fbe401f200b93e42d3a9d36",
    "std+extra": "35e2a0a570400f31f2add82e6c45deca5fde6d6f65f9bf78f7071defe32388b2",
    "force": "5bac6c849f6ed9399c6e94f816c1ab4b8989aa95ba30a537b3b96114569b7616",
    "force+extra": "57340e6a5cd3c39c0d8d37a0e81e22b8487e739cbe94a8677fcb1fa7004c2a05",
    "full": "62085f01ff189c576697bffcc9517fd63fa73471f0d4aa171a32e11ef6a3cde9",
    "full+extra": "6e5dc34f8d9228d7870c97806ed6ddb8a65fd164e3467f9984863b2c005e14f9",
    "bypass": "bb1bca192d396d8797abaaad5e8b19dc2d6d74d46ed0137d28d3b633f1e36052",
    "bypass+extra": "63a96aedcd935b218bce44505efed036fbd345adb9b53223b8d2de6b03e274dc",
    "all": "889d91ca7eb8d4c20d86f5289c19d668e954d5d594a33330b65da64d5a4274de",
}


def patch_so_table(data, profile):
    """Build 5.4.11 (versionCode 24001341): stessa tabella di byte di f1mobile_patcher_23(1).py.

    Sono patch a offset fissi (stub, salti e codice offline aggiunto in zone libere), quindi valgono SOLO per la
    libreria con lo SHA-256 originale; il risultato viene verificato con lo SHA-256 atteso dopo le patch.
    Ritorna (nuovi_byte, numero_patch_applicate)."""
    import patch_table_5411 as T
    if profile == "none":
        print("   [--] profilo none: build 5.4.11 riconosciuta, nessuna patch (solo ri-firma)")
        return bytes(data), 0
    buf = bytearray(data)
    for off, hx in T.PATCHES:
        rep = bytes.fromhex(hx)
        if off + len(rep) > len(buf):
            print(f"   [!] patch a 0x{off:X} fuori dalla libreria: ABORT, libreria non modificata")
            return bytes(data), 0
        buf[off:off + len(rep)] = rep
    got = hashlib.sha256(buf).hexdigest()
    if got != T.PATCHED_SHA256:
        print(f"   [!] SHA-256 del risultato ({got[:12]}...) diverso da quello atteso ({T.PATCHED_SHA256[:12]}...): ABORT, libreria non modificata")
        return bytes(data), 0
    print(f"   [OK]   build 5.4.11: {len(T.PATCHES)} patch applicate (tabella dello script 23)")
    print(f"   [OK]   verifica SHA-256 del risultato: {got[:16]}...")
    return bytes(buf), len(T.PATCHES)


def patch_so(data, extra, profile=DEFAULT_PROFILE):
    """Ritorna (nuovi_byte, numero_patch_applicate)."""
    h = hashlib.sha256(data).hexdigest()
    try:
        import patch_table_5411 as _T
        if h == _T.ORIGINAL_SHA256:
            return patch_so_table(data, profile)
    except ImportError:
        pass
    if h != EXPECTED_SHA256:
        print("   [!] SHA-256 della libreria (%s...) diverso dalle build supportate (7d07f863..., 90ae142f... = 5.4.11): non la tocco" % h[:8])
        return bytes(data), 0
    d = bytearray(data)
    if d[:4] != b"\x7fELF" or d[4] != 2 or struct.unpack_from("<H", d, 18)[0] != 183:
        print("   [!] la libreria non e' un ELF arm64")
        return bytes(d), 0
    phoff = struct.unpack_from("<Q", d, 0x20)[0]
    phsz, phnum = struct.unpack_from("<HH", d, 0x36)
    loads = []
    for i in range(phnum):
        t, fl, off, va, pa, fsz, msz, al = struct.unpack_from("<IIQQQQQQ", d, phoff + i * phsz)
        if t == 1:
            loads.append((va, off, fsz))

    def file_off(va):
        for v, o, s in loads:
            if v <= va < v + s:
                return o + (va - v)
        return None

    applied = 0
    skipped = []
    todo = list(PROFILES[profile])
    if extra:
        todo += [x for x in PATCH_EXTRA if x not in todo]
    for nome, va, atteso, nuovo in todo:
        fo = file_off(va)
        if fo is None:
            print(f"   [SKIP] {nome}: indirizzo 0x{va:x} non trovato")
            skipped.append(nome)
            continue
        n = len(nuovo)
        attuale = bytes(d[fo:fo + n])
        if attuale == nuovo:
            print(f"   [GIA'] {nome}")
            continue
        if attuale.hex() != atteso:
            print(f"   [SKIP] {nome}: a 0x{va:x} trovo {attuale.hex()} invece di {atteso}")
            skipped.append(nome)
            continue
        d[fo:fo + n] = nuovo
        print(f"   [OK]   {nome}")
        applied += 1
    print(f"   --> patch applicate: {applied}/{len(todo)}" + (f" (saltate: {len(skipped)})" if skipped else ""))
    key = profile + ("+extra" if extra and any(x not in PROFILES[profile] for x in PATCH_EXTRA) else "")
    want = PATCHED_SHA256.get(key)
    if want and not skipped:
        got = hashlib.sha256(d).hexdigest()
        if got != want:
            print(f"   [!] SHA-256 del risultato ({got[:12]}...) diverso da quello atteso ({want[:12]}...): ABORT, libreria non modificata")
            return bytes(data), 0
        print(f"   [OK] verifica SHA-256 del risultato: {got[:16]}...")
    return bytes(d), applied


# ---------------------------------------------------------------- chiave di firma
def load_or_create_key(folder):
    try:
        from cryptography import x509
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import rsa
        from cryptography.x509.oid import NameOID
    except ImportError:
        sys.exit("Manca la libreria 'cryptography'. Installala con:  pip install cryptography")

    kp = os.path.join(folder, "patcher_key.pem")
    cp = os.path.join(folder, "patcher_cert.pem")
    if os.path.exists(kp) and os.path.exists(cp):
        key = serialization.load_pem_private_key(open(kp, "rb").read(), None)
        cert = x509.load_pem_x509_certificate(open(cp, "rb").read())
    else:
        print("Creo la chiave di firma (una volta sola)...")
        key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "F1 Offline Patch")])
        cert = (x509.CertificateBuilder().subject_name(name).issuer_name(name)
                .public_key(key.public_key()).serial_number(x509.random_serial_number())
                .not_valid_before(datetime.datetime(2020, 1, 1))
                .not_valid_after(datetime.datetime(2060, 1, 1))
                .sign(key, hashes.SHA256()))
        open(kp, "wb").write(key.private_bytes(
            serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
            serialization.NoEncryption()))
        open(cp, "wb").write(cert.public_bytes(serialization.Encoding.PEM))
    cert_der = cert.public_bytes(serialization.Encoding.DER)
    pub_der = key.public_key().public_bytes(
        serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)
    return key, cert_der, pub_der


# ---------------------------------------------------------------- firma APK v2
def lp(b):
    return struct.pack("<I", len(b)) + b


def make_v2_block(sec1, cd, count, key, cert_der, pub_der):
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.asymmetric import padding

    eocd_for_digest = struct.pack("<4sHHHHIIH", b"PK\x05\x06", 0, 0, count, count,
                                  len(cd), len(sec1), 0)
    chunk = 1 << 20
    digests, n = [], 0
    for sec in (sec1, cd, eocd_for_digest):
        mv = memoryview(sec)
        for i in range(0, len(sec), chunk):
            c = mv[i:i + chunk]
            h = hashlib.sha256()
            h.update(b"\xa5" + struct.pack("<I", len(c)))
            h.update(c)
            digests.append(h.digest())
            n += 1
    top = hashlib.sha256(b"\x5a" + struct.pack("<I", n) + b"".join(digests)).digest()

    ALGO = 0x0103  # RSASSA-PKCS1-v1_5 + SHA-256
    signed_data = (lp(lp(struct.pack("<I", ALGO) + lp(top)))   # digests
                   + lp(lp(cert_der))                          # certificati
                   + lp(b""))                                  # attributi aggiuntivi
    sig = key.sign(signed_data, padding.PKCS1v15(), hashes.SHA256())
    signer = lp(signed_data) + lp(lp(struct.pack("<I", ALGO) + lp(sig))) + lp(pub_der)
    signers = lp(lp(signer))
    pair = struct.pack("<QI", 4 + len(signers), 0x7109871A) + signers
    size = len(pair) + 8 + 16
    return struct.pack("<Q", size) + pair + struct.pack("<Q", size) + b"APK Sig Block 42"


# ---------------------------------------------------------------- ricostruzione APK
def is_old_signature(name):
    up = name.upper()
    if not up.startswith("META-INF/") or up.count("/") != 1:
        return False
    return up.endswith((".SF", ".RSA", ".DSA", ".EC")) or up == "META-INF/MANIFEST.MF"


def rebuild(src, dst, key, cert_der, pub_der, extra, profile=DEFAULT_PROFILE):
    raw = open(src, "rb").read()
    zf = zipfile.ZipFile(io.BytesIO(raw))
    out = bytearray()
    cd = bytearray()
    count = 0
    n_patched = 0
    found_lib = False

    for zi in zf.infolist():
        name = zi.filename
        if is_old_signature(name):
            continue
        nb = name.encode("utf-8" if zi.flag_bits & 0x800 else "cp437")

        off = zi.header_offset
        (_s, _v, _f, _m, ltime, ldate, _c, _cs, _us, nl, el) = struct.unpack_from("<4s5H3I2H", raw, off)
        start = off + 30 + nl + el
        payload = raw[start:start + zi.compress_size]
        method, crc, csize, usize = zi.compress_type, zi.CRC, zi.compress_size, zi.file_size

        if name == TARGET_LIB:
            found_lib = True
            print(f" - {name}")
            new, n = patch_so(zf.read(zi), extra, profile)
            if n:
                payload, method = new, 0
                crc, csize, usize = zlib.crc32(new) & 0xFFFFFFFF, len(new), len(new)
                n_patched += n

        align = 0
        if method == 0 and not name.endswith("/"):
            align = 16384 if name.endswith(".so") else 4
        ext = b""
        if align:
            pad = (-(len(out) + 30 + len(nb))) % align
            if 0 < pad < 4:
                pad += align
            if pad:
                ext = struct.pack("<HH", 0xD935, pad - 4) + b"\0" * (pad - 4)

        flag = zi.flag_bits & ~0x08          # niente data descriptor: scriviamo crc/size veri
        need = 20 if method else 10
        local_off = len(out)
        out += struct.pack("<4sHHHHHIIIHH", b"PK\x03\x04", need, flag, method, ltime, ldate,
                           crc, csize, usize, len(nb), len(ext))
        out += nb + ext + payload
        cd += struct.pack("<4s6H3I5H2I", b"PK\x01\x02",
                          (zi.create_system << 8) | zi.create_version, need, flag, method,
                          ltime, ldate, crc, csize, usize, len(nb), 0, 0, 0,
                          zi.internal_attr, zi.external_attr, local_off)
        cd += nb
        count += 1

    sec1, cdb = bytes(out), bytes(cd)
    del out, cd
    block = make_v2_block(sec1, cdb, count, key, cert_der, pub_der)
    eocd = struct.pack("<4sHHHHIIH", b"PK\x05\x06", 0, 0, count, count,
                       len(cdb), len(sec1) + len(block), 0)
    with open(dst, "wb") as f:
        f.write(sec1)
        f.write(block)
        f.write(cdb)
        f.write(eocd)
    return n_patched if found_lib else "nolib"


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    extra = "--extra" in sys.argv
    profile = DEFAULT_PROFILE
    for a in sys.argv[1:]:
        if a.startswith("--profile="):
            profile = a.split("=", 1)[1]
    if profile not in PROFILES:
        sys.exit("Profilo sconosciuto. Scegli tra: " + ", ".join(PROFILES))
    if not args:
        print(__doc__)
        sys.exit(1)

    folder = os.path.dirname(os.path.abspath(__file__))
    key, cert_der, pub_der = load_or_create_key(folder)
    multi = len(args) > 1
    patched_total = 0

    for src in args:
        if not os.path.exists(src):
            sys.exit(f"File non trovato: {src}")
        base, ext = os.path.splitext(src)
        dst = base + "_offline" + (ext or ".apk")
        print(f"\n== {src}")
        res = rebuild(src, dst, key, cert_der, pub_der, extra, profile)
        if res == "nolib":
            if not multi:
                sys.exit("Questo APK non contiene lib/arm64-v8a/libil2cpp.so.\n"
                         "Se il gioco e' diviso in piu' APK, passali tutti insieme "
                         "(quello con la libreria e' di solito config.arm64_v8a.apk).")
            print("   (nessuna libreria da patchare, solo ri-firmato)")
        else:
            patched_total += res
        bad = zipfile.ZipFile(dst).testzip()
        if bad:
            sys.exit(f"Errore: file corrotto nell'APK generato ({bad})")
        print(f"   -> {dst}  ({os.path.getsize(dst) / 1e6:.1f} MB)")

    if profile == "none":
        print("\nFatto: APK ri-firmato senza modifiche al codice (profilo none). Disinstalla l'originale e installa.")
    elif patched_total == 0:
        print("\nATTENZIONE: nessuna patch applicata (build diversa da quella attesa?).")
    else:
        print(f"\nFatto: {patched_total} patch applicate.")
        print("Disinstalla l'app originale e installa il nuovo APK (la firma e' cambiata).")
        print("ATTENZIONE OBB: disinstallare puo' cancellare /Android/obb/com.codemasters.F1Mobile/ (i dati del gioco).")
        print("Prima salva la cartella (adb pull /sdcard/Android/obb/com.codemasters.F1Mobile .) e rimettila dopo l'installazione.")


if __name__ == "__main__":
    main()
