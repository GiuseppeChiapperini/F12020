import contextlib
import io
import zipfile

import patch_apk


def run(src, dst, key_folder, extra, profile="std"):
    """Ritorna [numero_patch, log]; -1 se l APK non contiene libil2cpp.so."""
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        key, cert_der, pub_der = patch_apk.load_or_create_key(key_folder)
        res = patch_apk.rebuild(src, dst, key, cert_der, pub_der, extra, profile)
        if res == "nolib":
            return [-1, buf.getvalue()]
        bad = zipfile.ZipFile(dst).testzip()
        if bad:
            raise RuntimeError("File corrotto nell APK generato: " + str(bad))
    return [res, buf.getvalue()]
