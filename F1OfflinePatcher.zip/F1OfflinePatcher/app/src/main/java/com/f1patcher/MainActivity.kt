package com.f1patcher

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import java.io.File
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private var pickedUri: Uri? = null
    private var pickedName = "F1Mobile.apk"
    private lateinit var btnPick: Button
    private lateinit var btnPatch: Button
    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            pickedUri = uri
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (c.moveToFirst() && i >= 0) pickedName = c.getString(i)
            }
            btnPatch.isEnabled = true
            log("APK selezionato: $pickedName")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Python.isStarted()) Python.start(AndroidPlatform(this))

        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }
        btnPick = Button(this).apply { text = "1) Pick APK"; setOnClickListener {
            picker.launch(arrayOf("*/*"))
        } }
        btnPatch = Button(this).apply { text = "2) Patch APK"; isEnabled = false; setOnClickListener { patch() } }
        logView = TextView(this).apply { textSize = 12f; typeface = android.graphics.Typeface.MONOSPACE
            text = "Scegli l APK di F1 Mobile Racing (arm64, con libil2cpp.so)." }
        scroll = ScrollView(this).apply { addView(logView) }
        root.addView(btnPick); root.addView(btnPatch)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun log(s: String) = runOnUiThread {
        logView.append("\n$s"); scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun patch() {
        val uri = pickedUri ?: return
        btnPick.isEnabled = false; btnPatch.isEnabled = false
        log("\nCopio l APK e applico le patch (puo richiedere un minuto)...")
        thread {
            try {
                val input = File(cacheDir, "input.apk")
                contentResolver.openInputStream(uri)!!.use { i -> input.outputStream().use { o -> i.copyTo(o, 1 shl 16) } }
                val outDir = File(filesDir, "out").apply { mkdirs() }
                val output = File(outDir, "${pickedName.removeSuffix(".apk")}_offline.apk")
                val res = Python.getInstance().getModule("bridge")
                    .callAttr("run", input.absolutePath, output.absolutePath, filesDir.absolutePath, false)
                    .asList()
                input.delete()
                val n = res[0].toInt()
                log(res[1].toString())
                if (n < 0) log("[!] Questo APK non contiene lib/arm64-v8a/libil2cpp.so (se e diviso, usa config.arm64_v8a.apk).")
                else if (n == 0) log("[!] Nessuna patch applicata (build diversa da quella attesa?).")
                else {
                    log("Fatto: $n patch applicate. Disinstalla l originale e installa quello nuovo.")
                    runOnUiThread { install(output) }
                }
            } catch (e: Throwable) {
                log("ERRORE: ${e.message}")
            } finally {
                runOnUiThread { btnPick.isEnabled = true; btnPatch.isEnabled = true }
            }
        }
    }

    private fun install(apk: File) {
        if (!packageManager.canRequestPackageInstalls()) {
            startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
            log("Abilita Installa app sconosciute per questa app, poi premi di nuovo Patch APK.")
            return
        }
        val u = FileProvider.getUriForFile(this, "$packageName.fileprovider", apk)
        startActivity(Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(u, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        })
    }
}
