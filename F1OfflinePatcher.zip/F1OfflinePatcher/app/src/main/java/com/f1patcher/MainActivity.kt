package com.f1patcher

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageInstaller
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import java.io.File
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private data class Picked(val uri: Uri, val name: String)

    private val picked = mutableListOf<Picked>()
    private val outputs = mutableListOf<File>()
    private lateinit var btnPick: Button
    private lateinit var btnPatch: Button
    private lateinit var btnInstall: Button
    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView

    // Profilo "dl" = tutte le patch di "all" + il gioco crede di aver trovato il .ver e prova a scaricare le piste (esperimento). Per tornare a prima metti "all".
    private val PROFILE = "dl"

    private val picker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNullOrEmpty()) return@registerForActivityResult
        picked.clear(); outputs.clear(); btnInstall.isEnabled = false
        for (u in uris) {
            var n = "file.apk"
            contentResolver.query(u, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (c.moveToFirst() && i >= 0) n = c.getString(i)
            }
            picked += Picked(u, n)
        }
        btnPatch.isEnabled = true
        log("\nSelezionati ${picked.size} APK: " + picked.joinToString { it.name })
        if (picked.size > 1) log("(gioco diviso in split: verranno firmati tutti con la stessa chiave e installati insieme)")
    }

    private val installResult = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            when (val st = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, -1)) {
                PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                    @Suppress("DEPRECATION")
                    val confirm = intent.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
                    if (confirm != null) startActivity(confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
                PackageInstaller.STATUS_SUCCESS -> log("Installazione completata.")
                else -> log("Installazione fallita (codice $st): " +
                    intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE) +
                    "\nSe dice conflitto di firma/INCONSISTENT: disinstalla prima il gioco originale.")
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Python.isStarted()) Python.start(AndroidPlatform(this))

        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }
        btnPick = Button(this).apply { text = "1) Scegli APK (anche piu' di uno)"; setOnClickListener {
            picker.launch(arrayOf("*/*"))
        } }
        btnPatch = Button(this).apply { text = "2) Patcha"; isEnabled = false; setOnClickListener { patch() } }
        btnInstall = Button(this).apply { text = "3) Installa"; isEnabled = false; setOnClickListener { install() } }
        logView = TextView(this).apply {
            textSize = 12f; typeface = android.graphics.Typeface.MONOSPACE
            text = "Scegli l'APK di F1 Mobile Racing (arm64). Se il gioco e' diviso, seleziona base.apk + config.arm64_v8a.apk + gli altri split insieme."
        }
        scroll = ScrollView(this).apply { addView(logView) }
        root.addView(btnPick); root.addView(btnPatch); root.addView(btnInstall)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        val f = IntentFilter(ACTION_INSTALL)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(installResult, f, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(installResult, f)
    }

    override fun onDestroy() { unregisterReceiver(installResult); super.onDestroy() }

    private fun log(s: String) = runOnUiThread {
        logView.append("\n$s"); scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun patch() {
        if (picked.isEmpty()) return
        val profile = PROFILE
        btnPick.isEnabled = false; btnPatch.isEnabled = false; btnInstall.isEnabled = false
        log("\nApplico TUTTE le patch (profilo $profile). Puo' richiedere qualche minuto...")
        thread {
            try {
                val outDir = File(filesDir, "out").apply { deleteRecursively(); mkdirs() }
                outputs.clear()
                var patched = 0
                var libFound = false
                for (p in picked) {
                    val input = File(cacheDir, "input.apk")
                    contentResolver.openInputStream(p.uri)!!.use { i -> input.outputStream().use { o -> i.copyTo(o, 1 shl 16) } }
                    val output = File(outDir, p.name.removeSuffix(".apk") + "_offline.apk")
                    val res = Python.getInstance().getModule("bridge")
                        .callAttr("run", input.absolutePath, output.absolutePath, filesDir.absolutePath, false, profile)
                        .asList()
                    input.delete()
                    val n = res[0].toInt()
                    log("== ${p.name}\n" + res[1].toString())
                    if (n < 0) log("   (nessuna libreria da patchare: solo ri-firmato)")
                    else { libFound = true; patched += n }
                    outputs += output
                }
                when {
                    !libFound -> log("[!] Nessun APK contiene lib/arm64-v8a/libil2cpp.so. Aggiungi config.arm64_v8a.apk.")
                    patched == 0 -> log("[!] Nessuna patch applicata (build diversa da quella attesa?).")
                    else -> {
                        log("Fatto: $patched patch applicate. Disinstalla il gioco originale e premi Installa.")
                        runOnUiThread { btnInstall.isEnabled = true }
                    }
                }
            } catch (e: Throwable) {
                log("ERRORE: ${e.message}")
            } finally {
                runOnUiThread { btnPick.isEnabled = true; btnPatch.isEnabled = true }
            }
        }
    }

    private fun install() {
        if (!packageManager.canRequestPackageInstalls()) {
            startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
            log("Abilita 'Installa app sconosciute' per questa app, poi premi di nuovo Installa.")
            return
        }
        try {
            val pi = packageManager.packageInstaller
            val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
            val id = pi.createSession(params)
            pi.openSession(id).use { s ->
                for (f in outputs) {
                    s.openWrite(f.name, 0, f.length()).use { o ->
                        f.inputStream().use { it.copyTo(o, 1 shl 16) }
                        s.fsync(o)
                    }
                }
                val intent = Intent(ACTION_INSTALL).setPackage(packageName)
                val flags = PendingIntent.FLAG_UPDATE_CURRENT or
                    (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
                s.commit(PendingIntent.getBroadcast(this, id, intent, flags).intentSender)
            }
            log("Installazione avviata (${outputs.size} file)...")
        } catch (e: Throwable) {
            log("ERRORE installazione: ${e.message}")
        }
    }

    companion object { const val ACTION_INSTALL = "com.f1patcher.INSTALL_RESULT" }
}
