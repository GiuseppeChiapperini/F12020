"""
logcat_unity.py - riassume un logcat di un gioco Unity/il2cpp: eccezioni distinte con le prime righe dello stack,
errori [Tag] ripetuti e eventuali morti del processo. E' il "passo 2" del metodo: lo stack trace e' la verita'.

Uso:
    adb logcat -c
    (avvia il gioco, riproduci il problema)
    adb logcat -d > log.txt
    python logcat_unity.py log.txt
"""
import collections
import re
import sys


def read(path):
    raw = open(path, "rb").read()
    for enc in ("utf-8", "utf-16", "cp1252"):
        try:
            return raw.decode(enc)
        except Exception:
            pass
    return raw.decode("latin-1")


def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    txt = read(sys.argv[1]).replace("\r", "")
    lines = txt.split("\n")

    # --- eccezioni con stack (si toglie il prefisso logcat "MM-GG hh:mm:ss.mmm E/Unity (pid): ")
    pref = re.compile(r"^\d\d-\d\d [\d:.]+\s+(?:\d+\s+\d+\s+)?[VDIWEF]/?\S*\s*\(?\s*\d*\)?:? ?")
    plain = [pref.sub("", l, count=1) if "Unity" in l else l for l in lines]
    exc = collections.Counter()
    first_seen = {}
    for i, l in enumerate(plain):
        m = re.match(r"\s*([\w.`]+Exception): (.*)", l)
        if not m:
            continue
        frames = []
        for nxt in plain[i + 1:i + 14]:
            n = nxt.strip()
            if n.startswith("at "):
                frames.append(re.sub(r" \[0x[0-9a-f]+\] in <filename unknown>:\d+", "", n))
            elif frames:
                break
        key = (m.group(1), tuple(frames[:3]))
        exc[key] += 1
        first_seen.setdefault(key, i + 1)

    print("=" * 70)
    print("ECCEZIONI DISTINTE (il primo frame e' il metodo che fallisce)")
    print("=" * 70)
    if not exc:
        print("nessuna eccezione trovata")
    for (name, frames), c in sorted(exc.items(), key=lambda kv: first_seen[kv[0]]):
        print(f"\n[{c}x] {name}  (riga {first_seen[(name, frames)]})")
        for f in frames:
            print("      " + f)

    # --- errori [Tag] del gioco
    errs = collections.Counter()
    for l in lines:
        m = re.search(r"E/Unity\s*\(\s*\d+\): (\[[^\]]+\].*)", l)
        if m:
            msg = re.sub(r"\?date=\d+", "", m.group(1))[:200]
            errs[msg] += 1
    print("\n" + "=" * 70)
    print("ERRORI [Tag] DEL GIOCO")
    print("=" * 70)
    for msg, c in errs.most_common(20):
        print(f"[{c}x] {msg}")

    # --- morte del processo
    print("\n" + "=" * 70)
    print("CHIUSURA / CRASH")
    print("=" * 70)
    pat = re.compile(r"FATAL EXCEPTION|Fatal signal|SIGSEGV|SIGABRT|am_proc_died|am_crash|Process .* has died|beginning of crash|backtrace:")
    hits = [l for l in lines if pat.search(l) and ("F1Mobile" in l or "codemasters" in l.lower() or "Fatal signal" in l or "backtrace" in l or "FATAL" in l)]
    if hits:
        for l in hits[:15]:
            print(l[:220])
    else:
        print("nessuna chiusura anomala nel log (il processo non e' morto)")


if __name__ == "__main__":
    main()
