"""
server_dati.py - mini server locale per i dati scaricabili di F1 Mobile Racing (DownloadableData).

Il gioco patchato cerca i file su http://127.0.0.1:8080/ invece che sui server Codemasters, ad esempio:
    http://127.0.0.1:8080/Production/DownloadableData/AndroidASTC/2.4.2.ver

Questo script serve i file di una cartella (ignora la parte "?date=..."), supporta Range e scrive nel log
OGNI richiesta del gioco, con "TROVATO" o "MANCA". I "MANCA" ti dicono esattamente cosa il gioco chiede
e non hai ancora.

Uso:
    python server_dati.py CARTELLA [porta]
      es.  python server_dati.py ~/f1data            (dentro la cartella: Production/DownloadableData/AndroidASTC/...)

Dove farlo girare:
  - Termux sul telefono:   pkg install python  poi  python server_dati.py ~/f1data
  - oppure sul PC, con il telefono collegato in USB:   adb reverse tcp:8080 tcp:8080
    (cosi' 127.0.0.1:8080 del telefono arriva al server sul PC)
"""
import os
import re
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import unquote, urlsplit

ROOT = os.path.abspath(sys.argv[1] if len(sys.argv) > 1 else ".")
PORT = int(sys.argv[2]) if len(sys.argv) > 2 else 8080


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):
        pass

    def _path(self):
        rel = unquote(urlsplit(self.path).path).lstrip("/")
        full = os.path.abspath(os.path.join(ROOT, rel))
        if full != ROOT and not full.startswith(ROOT + os.sep):
            return rel, None
        return rel, full if os.path.isfile(full) else None

    def _serve(self, head):
        rel, full = self._path()
        if full is None:
            print(f"MANCA    {rel}   (richiesta intera: {self.path})", flush=True)
            self.send_response(404)
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        size = os.path.getsize(full)
        start, end, code = 0, size - 1, 200
        m = re.match(r"bytes=(\d*)-(\d*)$", self.headers.get("Range", "").strip())
        if m and (m.group(1) or m.group(2)):
            if m.group(1):
                start = int(m.group(1))
                end = int(m.group(2)) if m.group(2) else size - 1
            else:
                start = max(0, size - int(m.group(2)))
            end = min(end, size - 1)
            if start > end:
                self.send_response(416)
                self.send_header("Content-Range", f"bytes */{size}")
                self.send_header("Content-Length", "0")
                self.end_headers()
                return
            code = 206
        print(f"TROVATO  {rel}  ({size} byte{', range %d-%d' % (start, end) if code == 206 else ''})", flush=True)
        self.send_response(code)
        self.send_header("Content-Type", "application/octet-stream")
        self.send_header("Accept-Ranges", "bytes")
        if code == 206:
            self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        self.send_header("Content-Length", str(end - start + 1))
        self.end_headers()
        if head:
            return
        with open(full, "rb") as f:
            f.seek(start)
            left = end - start + 1
            while left > 0:
                chunk = f.read(min(1 << 20, left))
                if not chunk:
                    break
                try:
                    self.wfile.write(chunk)
                except (BrokenPipeError, ConnectionResetError):
                    return
                left -= len(chunk)

    def do_GET(self):
        self._serve(False)

    def do_HEAD(self):
        self._serve(True)


if __name__ == "__main__":
    if not os.path.isdir(ROOT):
        sys.exit(f"Cartella non trovata: {ROOT}")
    print(f"Servo {ROOT} su http://127.0.0.1:{PORT}/  (Ctrl+C per fermare)", flush=True)
    ThreadingHTTPServer(("0.0.0.0", PORT), Handler).serve_forever()
